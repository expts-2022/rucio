Moved to https://rucio.cern.ch/documentation/contributing
